# Huzaifa Voice Assistant

This is a voice assistant designed for visually impaired users. It allows voice-based control for opening apps, searching the web, and more — without any keyboard or mouse interaction.

## Installation

```bash
pip install huzaifa-voice-assistant
