# huzaifa_voice_assistant/__init__.py

from .main import run_assistant

# Run assistant automatically when imported
run_assistant()
