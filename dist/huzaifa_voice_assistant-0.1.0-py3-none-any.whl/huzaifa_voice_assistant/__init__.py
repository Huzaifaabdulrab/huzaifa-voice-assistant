# __init__.py
from .main import start

# Automatically run the assistant when the package is imported
start()
